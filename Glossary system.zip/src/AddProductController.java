/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import com.jfoenix.controls.JFXTextField;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.layout.StackPane;
import javax.swing.JOptionPane;
/**
 * FXML Controller class
 *
 * @author sai
 */
public class AddProductController implements Initializable {

    Database db=Database.getInstance();
    @FXML
    private JFXTextField id;
    @FXML
    private JFXTextField name;
    @FXML
    private JFXTextField count;
    @FXML
    private StackPane stack;

   
    @Override
    public void initialize(URL url, ResourceBundle rb) {

    }    

    @FXML
    private void back(ActionEvent event) {
        try {
            StackPane pane=FXMLLoader.load(getClass().getResource("Main.fxml"));  
            AdminLogin.root.getChildren().setAll(pane);
        } catch (IOException ex) {
            Logger.getLogger(AddProductController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    @FXML
    private void add_product(ActionEvent event) {
        if(Validator.checkRequiredValidator(id,name,count)){
            db.execute("insert into product(pid,pname,total) values("
                    +"'"+id.getText()+"',"
                    +"'"+name.getText()+"',"
                    + count.getText()
                    + ")");
             JOptionPane.showMessageDialog(null,"Record Added ", "Added"
                    + "", JOptionPane.INFORMATION_MESSAGE);     
        }
    }
    
}
