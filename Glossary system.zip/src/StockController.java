
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.layout.AnchorPane;
import com.jfoenix.controls.*;
import com.jfoenix.controls.cells.editors.TextFieldEditorBuilder;
import com.jfoenix.controls.cells.editors.base.GenericEditableTreeTableCell;
import com.jfoenix.controls.datamodels.treetable.RecursiveTreeObject;
import home.resource.animatefx.animation.FadeInRight;
import home.resource.animatefx.animation.FadeOutRight;
import home.resource.animatefx.animation.SlideInLeft;
import home.resource.animatefx.animation.SlideOutLeft;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.binding.Bindings;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.Label;
import javafx.scene.control.TreeItem;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;

public class StockController implements Initializable,EventHandler<ActionEvent>{
    int flag=0;
    int idx=0;
    JFXTreeTableView<Product> treeview;
    JFXDialog dialog;
    ObservableList<Product> list=FXCollections.observableArrayList();
    Database db=Database.getInstance();
    @FXML
    private StackPane stack;
    @FXML
    private AnchorPane anchor;
   @FXML
    private AnchorPane anchor1;
    @FXML
    private JFXTextField searchtf;    
    @FXML
    private Label searchlbl;
    @FXML
    private Label size;
  
    @Override
    public void initialize(URL url, ResourceBundle rb) {
     initTable();        
     }  
    public void loadData(){       
        try{
            list.clear();
            ResultSet rs=db.executeQuery("select * from product");            
            while(rs.next()){
                list.add(new Product(
                                       rs.getString("pname"),
                                       rs.getString("pid"),
                                       rs.getString("total")                                       
                ));
            }
        } catch (Exception ex) {
            System.out.println("####Exception at load data");
          //  Logger.getLogger(ProductController.class.getName()).log(Level.SEVERE, null, ex);
        }   
    }
    public void initTable(){             
        
    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ creating column ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//
        
                
        JFXTreeTableColumn<Product, String> namecol = new JFXTreeTableColumn<>("Product name");
        namecol.setPrefWidth(150);
        namecol.setCellValueFactory((param) ->{
        if(namecol.validateValue(param)) return param.getValue().getValue().name;
        else return namecol.getComputedValue(param);
        });

        JFXTreeTableColumn<Product, String> idcol = new JFXTreeTableColumn<>("Product id");
        idcol.setPrefWidth(150);
        idcol.setCellValueFactory((param) ->{
        if(idcol.validateValue(param)) return param.getValue().getValue().id;
        else return idcol.getComputedValue(param);
        });
 
          JFXTreeTableColumn<Product, String> totalcol = new JFXTreeTableColumn<>("Available");
        totalcol.setPrefWidth(150);
        totalcol.setCellValueFactory((param) ->{
        if(totalcol.validateValue(param)) return param.getValue().getValue().total;
        else return totalcol.getComputedValue(param);
        });               

        loadData();
        
    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ building table ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//
    
        final TreeItem<Product> root = new RecursiveTreeItem<Product>(list, RecursiveTreeObject::getChildren);         
        treeview = new JFXTreeTableView<Product>(root);
        treeview.setShowRoot(false);
        treeview.setEditable(true);
        treeview.getColumns().setAll(idcol, namecol,totalcol); 
        searchtf.textProperty().addListener((o,oldVal,newVal)->{
        treeview.setPredicate(user ->  user.getValue().id.get().contains(newVal)
                || user.getValue().name.get().contains(newVal)               
               );               
        });
 
        size.textProperty().bind(Bindings.createStringBinding(()->"Total Records "+treeview.getCurrentItemsCount(),
        treeview.currentItemsCountProperty()));

                treeview.setPrefSize(anchor1.getPrefWidth(), anchor1.getPrefHeight());
                idcol.setPrefWidth(anchor1.getPrefWidth()/3);
                namecol.setPrefWidth(anchor1.getPrefWidth()/3);               
                totalcol.setPrefWidth(anchor1.getPrefWidth()/3);               
                anchor1.getChildren().setAll(treeview);                                   
    }
       
    @FXML
    void delete(ActionEvent event) {
        String selectedid=treeview.getSelectionModel().getSelectedItem().getValue().id.getValue();
        db.execute("delete from product where pid='"+selectedid+"'");   
        loadData();
    }

    @FXML
    void in(ActionEvent event) {
        idx=1;      
      Dialog.loadInputDialog(stack, new Text("Enter Quantity to add"), "Add Quantity", this);
    }

    @FXML
    void out(ActionEvent event) {
        idx=2;
       Dialog.loadInputDialog(stack, new Text("Out Product"), "Out Product", this);       
    }
    @FXML
    void back(ActionEvent event) {
           try {
            StackPane pane=FXMLLoader.load(getClass().getResource("Main.fxml"));  
            AdminLogin.root.getChildren().setAll(pane);
        } catch (IOException ex) {
            Logger.getLogger(AddProductController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
     //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

    @Override
    public void handle(ActionEvent event) {
        String selectedid=treeview.getSelectionModel().getSelectedItem().getValue().id.getValue();
        int curr=Integer.parseInt(treeview.getSelectionModel().getSelectedItem().getValue().total.getValue());
        if(idx==1){
           int x=Integer.parseInt(Dialog.tf.getText());
           curr=curr+x;
           db.execute("update product set total='"+curr+"' where pid='"+selectedid+"'");
               treeview.getSelectionModel().getSelectedItem().getValue().total.setValue(curr+"");
        }
        else if(idx==2){
           int x=Integer.parseInt(Dialog.tf.getText());
           curr=curr-x;
           db.execute("update product set total='"+curr+"' where pid='"+selectedid+"'");
               treeview.getSelectionModel().getSelectedItem().getValue().total.setValue(curr+"");
        }
        Dialog.dialog.close();
        idx=0;
    }

}
class Product extends RecursiveTreeObject<Product>{
    StringProperty name;
    StringProperty id;
    StringProperty total;
   
    
    public Product(String name, String id,String total) {
        this.name = new SimpleStringProperty(name);
        this.id = new SimpleStringProperty(id) ;
        this.total = new SimpleStringProperty(total) ;               
    }
     
}
