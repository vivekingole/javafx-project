



/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXDialog;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import com.jfoenix.controls.JFXSpinner;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;
import javax.swing.JOptionPane;
public class AdminLoginController implements Initializable {

    @FXML
    private JFXTextField user;
    @FXML
    private JFXPasswordField pass;     
    Database db=Database.getInstance();
    @FXML
    private JFXButton btn;
   @FXML
    private StackPane stack;
    @Override    
    public void initialize(URL url, ResourceBundle rb) {          
    }    

    @FXML
    private void login(ActionEvent event) {
        try {                  
            String username=user.getText();                       
            String password=pass.getText();                        
            if(username.equals("")||password.equals("")){
            }else{                            
            ResultSet rs=db.executeQuery("select * from admin");
            rs.next();
               if(username.equals(rs.getString("name"))&&password.equals(rs.getString("password"))){
                   JOptionPane.showMessageDialog(null,"Login Successful ", "Success"
                    + "", JOptionPane.INFORMATION_MESSAGE);
                   
                    StackPane pane=FXMLLoader.load(getClass().getResource("Main.fxml"));
                    AdminLogin.root.getChildren().setAll(pane);  
            
                   
                }else{
                   JOptionPane.showMessageDialog(null,"Login Failed ", "Fail Login"
                    + "", JOptionPane.ERROR_MESSAGE);               
               }               
            }                                          
        } catch (Exception e) {
             JOptionPane.showMessageDialog(null,e.getMessage(), "Exception"
                    + "", JOptionPane.WARNING_MESSAGE);               
        }
    }
   
}
