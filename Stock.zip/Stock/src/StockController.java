
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.layout.AnchorPane;
import com.jfoenix.controls.*;
import com.jfoenix.controls.cells.editors.TextFieldEditorBuilder;
import com.jfoenix.controls.cells.editors.base.GenericEditableTreeTableCell;
import com.jfoenix.controls.datamodels.treetable.RecursiveTreeObject;
import home.resource.animatefx.animation.FadeInRight;
import home.resource.animatefx.animation.FadeOutRight;
import home.resource.animatefx.animation.SlideInLeft;
import home.resource.animatefx.animation.SlideOutLeft;
import java.io.File;
import java.io.IOException;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.binding.Bindings;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.Label;
import javafx.scene.control.TreeItem;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;

public class StockController implements Initializable,EventHandler<ActionEvent> {
    int flag=0;
    String selectedid,selectedname;
    JFXTreeTableView<Product> treeview;
    JFXDialog dialog;
    ObservableList<Product> list=FXCollections.observableArrayList();
    Database db=Database.getInstance();
    @FXML
    private StackPane stack;
    @FXML
    private AnchorPane anchor;
   @FXML
    private AnchorPane anchor1;
    @FXML
    private JFXTextField searchtf;    
    @FXML
    private Label searchlbl;
    @FXML
    private Label size;
    @FXML 
    private JFXTextField billno;
    @FXML 
    private JFXTextField retailer_name;
    
  
    @Override
    public void initialize(URL url, ResourceBundle rb) {
    searchtf.setOpacity(0);
    searchtf.setStyle("-fx-prompt-text-fill:white");
    searchtf.focusedProperty().addListener(event->{
         if(!searchtf.isFocused())closeTF();
             });
       
             //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//
     initTable();        
     }  
    public void loadData(){       
        try{
            list.clear();
            ResultSet rs=db.executeQuery("select * from product");            
            while(rs.next()){
                list.add(new Product(rs.getString("pno"),
                                       rs.getString("pid"),
                                       rs.getString("pname"),
                                       rs.getString("total")                                       
                ));
            }
        } catch (Exception ex) {
            System.out.println("####Exception at load data");
          //  Logger.getLogger(ProductController.class.getName()).log(Level.SEVERE, null, ex);
        }   
    }
    public void initTable(){             
        
    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ creating column ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//
        
          JFXTreeTableColumn<Product, String> idcol = new JFXTreeTableColumn<>("Product id");
        idcol.setPrefWidth(150);
        idcol.setCellValueFactory((param) ->{
        if(idcol.validateValue(param)) return param.getValue().getValue().id;
        else return idcol.getComputedValue(param);
        });
        
                
        JFXTreeTableColumn<Product, String> namecol = new JFXTreeTableColumn<>("Product name");
        namecol.setPrefWidth(150);
        namecol.setCellValueFactory((param) ->{
        if(namecol.validateValue(param)) return param.getValue().getValue().name;
        else return namecol.getComputedValue(param);
        });

        /*JFXTreeTableColumn<Product, String> nocol = new JFXTreeTableColumn<>("Serial no.");
        nocol.setPrefWidth(150);
        nocol.setCellValueFactory((param) ->{
        if(nocol.validateValue(param)) return param.getValue().getValue().no;
        else return nocol.getComputedValue(param);
        });
          */
          JFXTreeTableColumn<Product, String> totalcol = new JFXTreeTableColumn<>("Available");
        totalcol.setPrefWidth(150);
        totalcol.setCellValueFactory((param) ->{
        if(totalcol.validateValue(param)) return param.getValue().getValue().total;
        else return totalcol.getComputedValue(param);
        });               

   
    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Loading data ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

        loadData();
        
    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ building table ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//
    
        final TreeItem<Product> root = new RecursiveTreeItem<Product>(list, RecursiveTreeObject::getChildren);         
        treeview = new JFXTreeTableView<Product>(root);
        treeview.setShowRoot(false);
        treeview.setEditable(true);
        treeview.getColumns().setAll(idcol, namecol,totalcol); 
        searchtf.textProperty().addListener((o,oldVal,newVal)->{
        treeview.setPredicate(user -> user.getValue().id.get().contains(newVal)
                || user.getValue().no.get().contains(newVal)
                || user.getValue().name.get().contains(newVal)               
               );               
        });
 
        size.textProperty().bind(Bindings.createStringBinding(()->"Total Records "+treeview.getCurrentItemsCount(),
        treeview.currentItemsCountProperty()));

                treeview.setPrefSize(anchor1.getPrefWidth()+5, anchor1.getPrefHeight()+5);
                //nocol.setPrefWidth(anchor1.getPrefWidth()/4);
                idcol.setPrefWidth(anchor1.getPrefWidth()/4);
                namecol.setPrefWidth(anchor1.getPrefWidth()/4);               
                totalcol.setPrefWidth(anchor1.getPrefWidth()/4);               
                anchor1.getChildren().setAll(treeview);                                   
    }
       
    //~~~~~~~~~~~~~~~~~~~~~~~~~~ search animation ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//
    @FXML
    private void searchExit(MouseEvent event) {
        closeTF();
    }
    public void closeTF() {
        new SlideInLeft(searchlbl).play();
        new FadeOutRight(searchtf).play();
        flag=0;        
    }
    @FXML
    private void searchEnter(MouseEvent event) {
        if(flag==0){
        searchtf.requestFocus();
        searchtf.clear();
        new SlideOutLeft(searchlbl).play();
        new FadeInRight(searchtf).play();
        flag=1;        
        }        
    }
    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~Operation on table~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//
   
      @FXML
    void delete(ActionEvent event) {
        try{
        if(!treeview.getSelectionModel().isEmpty()){
        Product p=treeview.getSelectionModel().getSelectedItem().getValue();
        selectedid=p.id.getValue();
         Dialog.loadInputDialog(stack, new Text("Enter Confirmation Password :"), "delete", this);
        }else{
             Util.notify("Invalid Operation","First Select the row",Util.Notification.error);                
        }
        }catch(Exception e){ 
             Util.notify("Invalid Operation","First Select the row",Util.Notification.error);                
        }
    }

    @FXML
    void in(ActionEvent event) {
        try{
        if(!treeview.getSelectionModel().isEmpty()){
            if(billno.getText().equals("") || retailer_name.getText().equals("")){
                Dialog.loadDialog(stack, new Text("Invalid operation"), new Text("Enter Bill number and Retailer name first"));
            }else{            
                Product p=treeview.getSelectionModel().getSelectedItem().getValue();
                selectedid=p.id.getValue();
                selectedname=p.name.getValue();
                Dialog.InDialog(stack, new Text("Enter Quantity to Add :"), "In Product", this);
            }
        }else{
             Util.notify("Invalid Operation","First Select the row",Util.Notification.error);                
        }
        }catch(Exception e){ 
             Util.notify("Invalid Operation","First Select the row",Util.Notification.error);                
        }
    }

    @FXML
    void out(ActionEvent event) {
        try{
        if(!treeview.getSelectionModel().isEmpty()){
        Product p=treeview.getSelectionModel().getSelectedItem().getValue();
        selectedid=p.id.getValue();
        selectedname=p.name.getValue();
        Dialog.loadInputDialog(stack, new Text("Enter Name and Quantity to remove :"), "Out Product", this,"Customer_Name","Quantity","rate");
        }else{
             Util.notify("Invalid Operation","First Select the row",Util.Notification.error);                
        }
        }catch(Exception e){ 
             Util.notify("Invalid Operation","First Select the row",Util.Notification.error);                
        }
    }
    @FXML
    void back(ActionEvent event) {
           try {
            StackPane pane=FXMLLoader.load(getClass().getResource("Main.fxml"));  
            AdminLogin.root.getChildren().setAll(pane);
        } catch (IOException ex) {
            Logger.getLogger(AddProductController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
     //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~Event Handler~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//
    
    @Override   ////// Eventhandler 
    public void handle(ActionEvent event) {  
        JFXButton src=(JFXButton)event.getSource();
        
        if(src.getText().equals("In Product")){
         int n=Integer.parseInt(Dialog.tf.getText());
         int total=Integer.parseInt((String)Util.getRowData("product", "total", 2, "pid", selectedid));
         total+=n;
         db.execute("update product set total='"+total+"' where pid='"+selectedid+"'");
         db.execute("insert into log(date,billno,id,buyer_name,out,in,total,bill,rate) values("
                 + "'"+LocalDate.now()+"',"
                 + "'"+billno.getText()+"',"
                 //+ "'"+LocalTime.now().getHour()+" : "+LocalTime.now().getMinute()+"',"
                 + "'"+selectedid+"',"
                 + "'"+retailer_name.getText()+"',"
                 + "'---',"
                 + "'"+n+"',"
                 + "'"+total+"',"              
                 + "'"+Dialog.tf1.getText()+"',"              
                 + "'---'"              
                 + ")");
         loadData();
         Util.notify("Updation Successful","New "+n+" items Added into "+selectedname,Util.Notification.success);    
        Dialog.dialog.close();
        }
        
        else if(src.getText().equals("Out Product")){
         int n=Integer.parseInt(Dialog.tf1.getText());
         int total=Integer.parseInt((String)Util.getRowData("product", "total", 2, "pid", selectedid));         
         total-=n;
         if(total>=0){
         db.execute("update product set total='"+total+"' where pid='"+selectedid+"'");
         db.execute("insert into log(date,billno,id,buyer_name,out,in,total,bill,rate) values("
                 + "'"+LocalDate.now()+"',"
                  + "'---',"
                 + "'"+selectedid+"',"
                 + "'"+Dialog.tf.getText()+"',"
                 + "'"+n+"',"
                 + "'---',"
                 + "'"+total+"',"              
                 + "'"+Float.parseFloat(Dialog.tf2.getText())*n+"',"              
                 + "'"+Dialog.tf2.getText()+"'"              
                 + ")");
        
         try{
             float current_price=Float.parseFloat(Dialog.tf2.getText())*n;
             if(Util.checkRow("bill", "c_name", Dialog.tf.getText())){
             ResultSet rs=db.executeQuery("select * from bill where c_name='"+Dialog.tf.getText()+"'");
             rs.next();
             float Total=rs.getFloat(2);
             float remaining=rs.getFloat(4);
            Total+=current_price;
             remaining+=current_price;
             db.execute("update bill set total="+Total+", remaining="+remaining+" where c_name='"+Dialog.tf.getText()+"'");
             }else{
             db.execute("insert into bill(c_name,total,paid,remaining) values('"+Dialog.tf.getText()+"',"
                     + current_price+","
                     + 0.0+","
                     + current_price
                     + ")");                            
             }
              db.execute("insert into bill_history(b_name,b_date,b_time,b_payment) values("
                 + "'"+Dialog.tf.getText()+"',"
                 + "'"+LocalDate.now()+"',"
                 + "'"+LocalTime.now().getHour()+" : "+LocalTime.now().getMinute()+"',"
                 + "'- "+current_price+"'"
                 + ")");   
         }catch(Exception e){}       
         loadData();
         Util.notify("Updation Successful",n+" items of "+selectedname+" sold to "+Dialog.tf.getText(),Util.Notification.success);    
         }else{
             Dialog.loadDialog(stack, new Text("Invalid input"), new Text("Out value cannot greater than Total"));
         }
        Dialog.dialog.close();           
        }
        
        else if(src.getText().equals("delete")){
         String pass1=Dialog.tf.getText();
         String pass2=(String)Util.getFirstRowData("admin", "password2", 2);
         if(pass1.equals(pass2)){
           db.execute("delete from product where pid='"+selectedid+"'");
           Util.notify("Deletion Successful","Product name "+selectedid+" deleted.",Util.Notification.success);    
           loadData();
         }else{
           Util.notify("Removation Failure","Sorry Password incorrect",Util.Notification.error);                 
         }
        Dialog.dialog.close();
        }
    }

}
class Product extends RecursiveTreeObject<Product>{
    StringProperty id;
    StringProperty name;
    StringProperty no;
    StringProperty total;
   
    
    public Product(String no, String id, String name,String total) {
        this.id = new SimpleStringProperty(id);
        this.name = new SimpleStringProperty(name);
        this.no = new SimpleStringProperty(no) ;
        this.total = new SimpleStringProperty(total) ;               
    }
     
}
