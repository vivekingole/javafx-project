


import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import java.io.File;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;

import javafx.scene.layout.StackPane;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;
import javafx.stage.FileChooser;
import javax.swing.JOptionPane;

public class AdminRegistrationController implements Initializable {

    public static JFXButton close;
    String path1,path2;
    @FXML
    private JFXTextField user;
    @FXML
    private JFXPasswordField pass1;
    @FXML
    private JFXPasswordField pass2;
    @FXML
    private StackPane sp;
     Database db=Database.getInstance();
    @FXML
    private Circle img;
     @FXML
    private AnchorPane anchor;
    @FXML
    private JFXButton closebtn;
    @FXML
    private JFXPasswordField password2;
    @Override
    public void initialize(URL url, ResourceBundle rb) {       
        path1="img\\user.jpg";
        img.setFill(new ImagePattern(new Image(new File(path1).toURI().toString())));  
        close=closebtn;
    }    

    @FXML
    private void register(ActionEvent event) {
        try{
        if(!Validator.checkRequiredValidator(user)){
             JOptionPane.showMessageDialog(null,"Invalid", "Please fill all fields !"
                    + "", JOptionPane.WARNING_MESSAGE);               
        }
        else{
            if(pass1.getText().equals(pass2.getText())){
                path2="img\\admin.jpg";
                new Util().copyFile(path1,path2);
                
            db.execute("insert into admin(name,password,password2) values("
                   + "'"+user.getText()+"',"                        
                   + "'"+pass1.getText()+"',"
                   + "'"+password2.getText()+"'"
                   + ")");              
            AdminLoginController.registror=1;
            AdminLoginController.image.setFill(new ImagePattern(new Image(new File("img\\admin.jpg").toURI().toString())));  
            JOptionPane.showMessageDialog(null,"Registration successful", "Successful", JOptionPane.INFORMATION_MESSAGE);         
            Dialog.dialog.close();            
           }
            else{
                 JOptionPane.showMessageDialog(null,"Password does not matched.", "Invalid"
                        + "", JOptionPane.WARNING_MESSAGE);               
            } 
        }
        }catch(Exception ex){    }
    }

    @FXML
    private void openimg(MouseEvent event) {                
        FileChooser fc=new FileChooser();
        File file2=fc.showOpenDialog(anchor.getScene().getWindow());
        if(file2!=null){
            path1=file2.getAbsolutePath();
            img.setFill(new ImagePattern(new Image(file2.toURI().toString())));                   
        }              
    }   
    
}
