/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import com.jfoenix.controls.JFXTextField;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.StackPane;
/**
 * FXML Controller class
 *
 * @author sai
 */
public class AddProductController implements Initializable {

    Database db=Database.getInstance();
    @FXML
    private JFXTextField no;
    @FXML
    private JFXTextField id;
    @FXML
    private JFXTextField name;
    @FXML
    private JFXTextField count;
    @FXML
    private StackPane stack;

   
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
     /*   no.setStyle("-fx-prompt-text-fill:white");
        id.setStyle("-fx-prompt-text-fill:white");
        name.setStyle("-fx-prompt-text-fill:white");
        count.setStyle("-fx-prompt-text-fill:white");
*/
    }    

    @FXML
    private void back(ActionEvent event) {
        try {
            StackPane pane=FXMLLoader.load(getClass().getResource("Main.fxml"));  
            AdminLogin.root.getChildren().setAll(pane);
        } catch (IOException ex) {
            Logger.getLogger(AddProductController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
     @FXML
    private void clear(ActionEvent event) {
        reset();
    }
    public void reset() {
        try {
            StackPane pane=FXMLLoader.load(getClass().getResource("AddProduct.fxml"));  
            AdminLogin.root.getChildren().setAll(pane);
        } catch (IOException ex) {
            Logger.getLogger(AddProductController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    @FXML
    private void add_product(ActionEvent event) {
        if(Validator.checkRequiredValidator(no,id,name,count)){
          if(
            db.execute("insert into product(pno,pid,pname,total) values("
                    +"'"+no.getText()+"',"
                    +"'"+id.getText()+"',"
                    +"'"+name.getText()+"',"
                    + count.getText()
                    + ")")
            ){
            Util.notify("Product Added", id.getText()+" "+name.getText()+" "+count.getText(), Util.Notification.success);
            reset();
          }else
            Util.notify("product adding failure", "ID cannot be repeated", Util.Notification.error);
              
        }
    }
    
}
