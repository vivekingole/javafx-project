
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.layout.AnchorPane;
import com.jfoenix.controls.*;
import com.jfoenix.controls.cells.editors.TextFieldEditorBuilder;
import com.jfoenix.controls.cells.editors.base.GenericEditableTreeTableCell;
import com.jfoenix.controls.datamodels.treetable.RecursiveTreeObject;
import home.resource.animatefx.animation.FadeInRight;
import home.resource.animatefx.animation.FadeOutRight;
import home.resource.animatefx.animation.SlideInLeft;
import home.resource.animatefx.animation.SlideOutLeft;
import java.io.File;
import java.io.IOException;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.binding.Bindings;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.Label;
import javafx.scene.control.TreeItem;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;

public class BillController implements Initializable,EventHandler<ActionEvent> {
    int flag=0;
    String selectedid,selectedpaid;
    JFXTreeTableView<Billing> treeview;
    JFXDialog dialog;
    ObservableList<Billing> list=FXCollections.observableArrayList();
    Database db=Database.getInstance();
    @FXML
    private StackPane stack;
    @FXML
    private AnchorPane anchor;
   @FXML
    private AnchorPane anchor1;
    @FXML
    private JFXTextField searchtf;    
    @FXML
    private Label searchlbl;
    @FXML
    private Label size;
    private float total;
    private float paid;
    private float remaining;
  
    @Override
    public void initialize(URL url, ResourceBundle rb) {
    searchtf.setOpacity(0);
    searchtf.focusedProperty().addListener(event->{
         if(!searchtf.isFocused())closeTF();
             });
       
             //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//
     initTable();        
     }  
    public void loadData(){       
        try{
            list.clear();
            ResultSet rs=db.executeQuery("select * from bill");            
            while(rs.next()){
                list.add(new Billing(rs.getString("c_name"),
                                       rs.getString("total"),
                                       rs.getString("paid"),
                                       rs.getString("remaining")                                       
                ));
            }
        } catch (Exception ex) {
            System.out.println("####Exception at load data");
          //  Logger.getLogger(BillingController.class.getName()).log(Level.SEVERE, null, ex);
        }   
    }
    public void initTable(){             
        
    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ creating column ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//
        
          JFXTreeTableColumn<Billing, String> idcol = new JFXTreeTableColumn<>("Customer Name");
        idcol.setPrefWidth(150);
        idcol.setCellValueFactory((param) ->{
        if(idcol.validateValue(param)) return param.getValue().getValue().id;
        else return idcol.getComputedValue(param);
        });
        
                
        JFXTreeTableColumn<Billing, String> paidcol = new JFXTreeTableColumn<>("Paid");
        paidcol.setPrefWidth(150);
        paidcol.setCellValueFactory((param) ->{
        if(paidcol.validateValue(param)) return param.getValue().getValue().paid;
        else return paidcol.getComputedValue(param);
        });

        JFXTreeTableColumn<Billing, String> remainingcol = new JFXTreeTableColumn<>("Remaining");
        remainingcol.setPrefWidth(150);
        remainingcol.setCellValueFactory((param) ->{
        if(remainingcol.validateValue(param)) return param.getValue().getValue().remaining;
        else return remainingcol.getComputedValue(param);
        });
 
          JFXTreeTableColumn<Billing, String> totalcol = new JFXTreeTableColumn<>("Total");
        totalcol.setPrefWidth(150);
        totalcol.setCellValueFactory((param) ->{
        if(totalcol.validateValue(param)) return param.getValue().getValue().total;
        else return totalcol.getComputedValue(param);
        });               

   
        loadData();
        
    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ building table ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//
    
        final TreeItem<Billing> root = new RecursiveTreeItem<Billing>(list, RecursiveTreeObject::getChildren);         
        treeview = new JFXTreeTableView<Billing>(root);
        treeview.setShowRoot(false);
        treeview.setEditable(true);
        treeview.getColumns().setAll(idcol,totalcol,paidcol,remainingcol); 
        searchtf.textProperty().addListener((o,oldVal,newVal)->{
        treeview.setPredicate(user -> user.getValue().id.get().contains(newVal)
                || user.getValue().remaining.get().contains(newVal)
                || user.getValue().paid.get().contains(newVal)               
                || user.getValue().total.get().contains(newVal)               
               );               
        });
 
        size.textProperty().bind(Bindings.createStringBinding(()->"Total Records "+treeview.getCurrentItemsCount(),
        treeview.currentItemsCountProperty()));

                treeview.setPrefSize(anchor1.getPrefWidth(), anchor1.getPrefHeight());
                remainingcol.setPrefWidth(anchor1.getPrefWidth()/4);
                idcol.setPrefWidth(anchor1.getPrefWidth()/4);
                paidcol.setPrefWidth(anchor1.getPrefWidth()/4);               
                totalcol.setPrefWidth(anchor1.getPrefWidth()/4);               
                anchor1.getChildren().setAll(treeview);                                   
    }
       
    //~~~~~~~~~~~~~~~~~~~~~~~~~~ search animation ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//
    @FXML
    private void searchExit(MouseEvent event) {
        closeTF();
    }
    public void closeTF() {
        new SlideInLeft(searchlbl).play();
        new FadeOutRight(searchtf).play();
        flag=0;        
    }
    @FXML
    private void searchEnter(MouseEvent event) {
        if(flag==0){
        searchtf.requestFocus();
        searchtf.clear();
        new SlideOutLeft(searchlbl).play();
        new FadeInRight(searchtf).play();
        flag=1;        
        }        
    }
    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~Operation on table~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//
   
      @FXML
    void delete(ActionEvent event) {
        try{
        if(!treeview.getSelectionModel().isEmpty()){
        Billing p=treeview.getSelectionModel().getSelectedItem().getValue();
        selectedid=p.id.getValue();
        Dialog.loadInputDialog(stack, new Text("Enter Confirmation Password :"), "delete", this);
        }else{
             Util.notify("Invalid Operation","First Select the row",Util.Notification.error);                
        }
        }catch(Exception e){ 
             Util.notify("Invalid Operation","First Select the row",Util.Notification.error);                
        }
    }

    @FXML
    void pay(ActionEvent event) {
        try{            
        if(!treeview.getSelectionModel().isEmpty()){
        Billing p=treeview.getSelectionModel().getSelectedItem().getValue();
        selectedid=p.id.getValue();
        total=Float.parseFloat(p.total.getValue());
        paid=Float.parseFloat(p.paid.getValue());
        remaining=Float.parseFloat(p.remaining.getValue());        
        Dialog.loadInputDialog(stack, new Text("Enter Payment :"), "pay", this);
        }else{
             Util.notify("Invalid Operation","First Select the row",Util.Notification.error);                
        }
        }catch(Exception e){ 
             Util.notify("Invalid Operation","First Select the row",Util.Notification.error);                
        }
    }

    @FXML
    void back(ActionEvent event) {
           try {
            StackPane pane=FXMLLoader.load(getClass().getResource("Main.fxml"));  
            AdminLogin.root.getChildren().setAll(pane);
        } catch (IOException ex) {
               System.out.println(ex.getMessage());
        }
    }
    
     //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~Event Handler~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//
    
    @Override   ////// Eventhandler 
    public void handle(ActionEvent event) {  
        JFXButton src=(JFXButton)event.getSource();        
        if(src.getText().equals("pay")){
         float n=Float.parseFloat(Dialog.tf.getText());
         paid+=n;
         remaining-=n;
         if(remaining>=0){
         db.execute("update bill set paid="+paid+", remaining="+remaining+" where c_name='"+selectedid+"'");
          db.execute("insert into bill_history(b_name,b_date,b_time,b_payment) values("
                 + "'"+selectedid+"',"
                 + "'"+LocalDate.now()+"',"
                 + "'"+LocalTime.now().getHour()+" : "+LocalTime.now().getMinute()+"',"
                 + "'+ "+n+"'"
                 + ")");         
         loadData();
         Util.notify("Updation Successful","Amount "+n+" paid by "+selectedid,Util.Notification.success);    
         }else{
             Dialog.loadDialog(stack, new Text("Invalid input"), new Text("Cannot pay more than Total bill"));
         }
        Dialog.dialog.close();
        }
        
        else if(src.getText().equals("delete")){
         String pass1=Dialog.tf.getText();
         String pass2=(String)Util.getFirstRowData("admin", "password2", 2);
         if(pass1.equals(pass2)){
           db.execute("delete from bill where c_name='"+selectedid+"'");
           loadData();
           Util.notify("Removation Successful","Customer "+selectedid+" Removed",Util.Notification.success);    
         }else{
           Util.notify("Removation Failure","Sorry Password incorrect",Util.Notification.error);                 
         }
          Dialog.dialog.close();
        }
    }

}
class Billing extends RecursiveTreeObject<Billing>{
    StringProperty id;
    StringProperty paid;
    StringProperty remaining;
    StringProperty total;
   
    
    public Billing(String id, String total, String paid,String remaining) {
        this.id = new SimpleStringProperty(id);
        this.paid = new SimpleStringProperty(paid);
        this.remaining = new SimpleStringProperty(remaining) ;
        this.total = new SimpleStringProperty(total) ;               
    }
     
}
